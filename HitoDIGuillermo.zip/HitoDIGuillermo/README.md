# Lista de productos

Este proyecto fue generado con [Angular CLI](https://github.com/angular/angular-cli) version 7.3.4 y busca ayudarme a sentar las bases conceptuales de Angular.

## Conceptos Iniciales

### Componentes

1. **`Interpolaciòn {{}}`**:

   * Es un enlace `unidireccional` **(One Way Binding)** de la clase al template.
   * Lo usado dentro de la interpolaciòn se llama `Template Expression` ya que usa al componente como una expresiòn. 
   * Permite realizar operaciones dentro y usar mètodos de la clase (parecido al comportamiento de la interpolaciòn en template literals ${} de ES6)

2. **`Directiva`**:

   * Es incluido en la metadata como valor de la propiedad `selector`.

3. **`Directivas estructurales "*"`**:

   * Se usan como atributos de HTML **`nombreDelaDirectiva='expresion de Js'`**, y remueven el elemento del DOM.
   * su **scope** es la etiqueta donde se aplica junto a sus hijos.
   * `*nfIf` funciona como un **if** de Js.
   * `*ngfor` funciona como un **for of** ò **for in**

4. **`Property Binding "[]"`**
   
   * Es un enlace `unidireccional` **(One Way Binding)** de la clase al template.
   * Se usa con la misma idea que la **Interpolaciòn**, pero en este caso se van a tocar directamente las propiedades del elemento del DOM.
   * Se usa para pasarle un valor a una propiedad de un elemento del DOM, es decir, una imágen `<img></img>` tiene un `src` entre sus propiedades, con el *Property Binding* en vez de hacer `src={{source.enMi.clase}}` hago `[src]="source.enMi.clase"`.
   * Para generalizar, la forma es: **`[propiedadHTML.propiedadEspecificaEnElDOM]='valorDentroDe.MiClase'`**, donde lo que està entre **[]** es la ruta a la propiedad del DOM que quiero modificar partiendo desde el elemento en que lo uso.
   * Como ejemplo concreto, si estoy en el elemento **img**, una `propiedad` de este es **[style.width.px]**; y la `expression` seria **'variableDentroDelTS'**.

5. **`Event Binding "()"`**:

   * Se usa `One Way Binding` pero en un sentido contrario al del `Property Binding`, ya que el evento y la data se pasan del HTML a la clase del TS para que esta la procese. 
   * En Este tipo de Binding, el evento invoca un mètodo desde el HTML, el mètodo invocado està dentro de la lògica del componente.
   * El nombre del evento va en parentesis y la `expresiòn` entre comillas simples (Como en el caso del **Property Binding**).  
   * La **expressiòn** generalmente generalmente invoca una funciòn declarada en la clase.

6. **`Two Way Binding y la directiva ngModel "[()]"`**:

   * Esta directiva es usada generalmente en formularios y por esto la pusieron en el mòdulo `**FormsModule**`, por lo tanto, hay que importarlo  para usarla.
   * Cuando se trabaja con datos ingresados por el usuario, hay que usar `**Two Way Binding**`.
   * Se usa la notaciòn `**[()]**` porque la directiva `**ngModel**` hace un **Property Binding** y un **Event Binding**, para que de esta manera haya un **Two Way Binding**.

7. **`Pipes "|"`**:

   * Los Pipes se usan en el template (HTML) y sirven para transformar Data justo antes de ser mostrada, segùn la documentaciòn de Angular: "pipes, a way to write display-value transformations that you can declare in your HTML".
   * Algunos pipes aceptan paràmetros los cuales van en comilla simple. En el caso de `**currency**` acepta el tipo de moneda , si se debe mostrar el simbolo y la cantidad de digitos que se van a mostrar, estos paràmetros lucirian asi => `**'USD' : 'symbol' : '1.2-2'**` .
   * Se pueden usar varios pipes en un mismo dato, lo ùnico que hay que hacer es separarlos con pipes `**|**`
   * Angular provee [varios Pipes](https://angular.io/guide/pipes#built-in-pipes)
   * Para debugging el pipe de JSON es bastante ùtil.
   * Se pueden hacer Pipes custom.

8. **`Interfaces`**:

   * Las interfaces crean un contrato en donde se define la estructura de un tipo de datos, y ayudan a encontrar errores de forma temprana.
   * Su nombre se puede declarar con una `I` como prefijo, pero no hay un consenso, por ejemplo, la guía de contribución de Typescript dice que no hay que usar ese prefijo. Lo importante es ser consistente.
   * Es importante conocer cuándo usar una *interface* y [acá](https://angular.io/guide/styleguide#interfaces) se explica, además, para saber que es un *declarable* (ver el enlace anterior), revisar [acá](https://angular.io/guide/glossary#declarable).
     * **TL:DR**, no se deben declarar interfaces para *declarables*, los cuales son *componentes*, *directivas* o *pipes*, se llaman declarables porque están en la sección **"declarations"** del módulo principal de la app, para revisar este módulo, ver el archivo `app.module.ts`.
   * Las interfaces **solo** estàn presentes durante el desarrollo, es decir, no se traducen a nada en JS.
   * En la carpeta *interfaces* del proyecto se muestra como declararla y en el archivo *product-list.component.ts* está su uso.

9. **`Estilos "styleURLs ò style"`**:

   * Dependiendo de como se configure la metadata en el decorador, se puede usar:
     * Un archivo de CSS externo usando la propiedad `**styleUrls**` y poniendo la ruta del archivo css dentro de un array, o
     * Se pone un array con estilos usando la propiedad `**style**`, en *src/app/pages/product-detail-page/product-detail-page.component.ts* se puede ver un ejemplo.

10. **`Component Lifecycle Hooks`**:

    * [Acá](https://angular.io/guide/glossary#lifecycle-hook) está su definición y [acá](https://angular.io/guide/lifecycle-hooks) se explican con más detalle.
      * **TL:DR**, son interfaces y cada una tiene un método, estos métodos se inicia en determinada momento de la carga de los *componentes* o *directivas* (en el primer enlace está ese orden), y la gracia es que con estos hooks, puedo especificar en que momento del componente o directiva, se carga x método o propiedad de la Clase.
    * En los componentes del proyecto se usan:
      * OnInit => **ngOnInit**
      * OnChanges => **ngOnChanges**
      * OnDestroy => **ngOnDestroy**

11. **`Custom pipes`**
    * [Acá](https://angular.io/guide/glossary#pipe) de puede ver la definición
    * Generalmente se pone en la carpeta `"shared"` y el nombre termina con `.pipe.ts`
    * La mejor forma de generarlos es con el CLI ya que de esta manera quedan importados en el `app.module` automàticamente.
    * En el còdigo pongo datos generales de lo que voy haciendo para generar el pipe.

### Comunicación entre `Componentes Anidados`

No tiene que ver estrictamente con los `Componentes Anidados`, pero teniendo en cuenta que hay *componentes anidados* que son genéricoos en la aplicación, e incluso se pueden usar en varias aplicaciones, es importante aclarar que según [la guía de estilos de Angular](https://angular.io/guide/styleguide#shared-feature-module), estos componentes van en una carpeta shared, y en mi caso personal, me parece más comodo que además de estar en la carpeta shared, estén divididos en subcarpetas cuyo nombre no tenga ningún sufijo ni prefijo. En el caso de la app del repositorio, el componente que muestra las estrellas que tiene el producto es un componente que estará anidado y se puede mostrar en varios lugares de la aplicación.

1. **`Component As a Directive`**

    Dentro del HTML del componente padre, se usa al componente hijo como una etiqueta html custom, con el nombre que se le puso en la propiedad "selector" de la metadata del componente, es decir en @Component({}).

2. **`Decorador @Input()`**

    * Se usa este Decorador (que es un método) para indicar los datos que van a pasar de la Clase Padre (**Parent Component**) al Template hijo (**Child Component**),
    * Como la data pasa de la clase al template, se usa el **`Property Binding "[]"`**
    * En general, lo que se hace es:
      1. Se declara la data en product-list.
      2. En el html de product-list y dentro de la directiva del **Child component**:
         * Se declara entre `**[]**` la variable que se declaro en el decorador @Input del *Child component*. y,
         * Como expresion se pone el nombre de la variable que contiene la data pasada por el *Parent Component*.
      3. Para finalizar, hay que tener en cuenta que en este caso la data que se le va a pasar al *Child Component* es primero procesada en el template del *Parent Component* por un *for of* (porque originalmente es un array con varios juegos de datos) y despues, ahí ya se obtiene exactamente el dato que necesito. Más detalles desde la linea 48 hasta la 77 del template `product-list-page.component.html`
    * En la clase del componente puse comentarios específicos respecto a la forma en que se traen y se usan los datos desde el "servidor", lo pongo entre comillas porque en este caso el llamado se hace a un json local. (gg)

3. **`Decorador @Output`**
   * Este decorador siempre va con un EventEmitter.
   * Como la data va del Template a la Clase se usa el **`Event Binding` "()"**, 
   * Para entender bien como funciona, revisar el componente y template *"start-rating"* para la parte uno, y lo mismo, pero en la directiva **app-star-rating** dentro de *"product-list-page"* para la parte 2.
   * En general, en la clase se usa el decorador **`@Output`**, el cual tiene *Event Emmiter* que reciben lo emitido en un método `x` accionado por el usuario (la acción que hace el usuario para gatillar el método que acciona el `emit()` se escribe en el template, como se hace con cualquier event emmiter).
   * Más específicamente los pasos se dividen en 2 partes:
     1. En el componente que emite
        1. En el template del componente se declara un evento (en este caso `(click)`), el cual acciona un método declarado en la Clase.
        2. El método accionado desde el template (en este caso `onClickRatingEmit()`) emitira x dato con el método `.emit()`.
        3. Lo emitido en el punto anterior es recibido por los `Event Emmiter` puestos en el Decorador `@Output`.
     2. En el componente que recibe
        1. El *Event Emmiter* puesto en la parte anterior en *@output* se pone en el template de la directiva desde donde se emite (**app-star-rating**), y personalmente, lo pienso como "declarar un **Event Emmiter custom**" y por lo tanto, se hace *"Event Biding"* y va en ().
        2. El *Event Emmiter custom* tiene declarado un método dentro de la directiva, el cual recibe como argumento un *$event* (Este es de Angular) y acá es donde se hace el binding entre componentes, porque el método disparado por el componente de la directiva (**app-star-rating**) está en la clase que finalmente recibe el Evento y data del componente con el @Output.
   * [Acà](https://developer.mozilla.org/en-US/docs/Web/Events) se pueden ver varios eventos del DOM  

4.  **`Services y Dependency Injection`**
* El servicio se debe registrar en el **Angular Injector** quien crea una ùnica instancia de cada Clase de los Servicios cuando son usados por los componentes de la aplicaciòn. 
* La Instanciaciòn ò Injection (en terminos de Angular) sucede cuando los servicios son requeridos.
* El patròn que usa el **`Dependency Injection`** de Angular se llama [singletone](https://en.wikipedia.org/wiki/Singleton_pattern). 
* Ademàs del **`Root Aplication Injector`** quien hace que el servicio estè disponible para todos los componentes, Angular tiene un **`Component Injector`**, el cual refleja el arbol de los componentes y hace que el servicio este disponible solo para el componente donde se registra, y sus **Child Components**, en este ùltimo caso, el servicio se instanciaria tantas veces como el componente es usado o instanciado y por lo tanto deja de usar el patròn "singletone".
* Teniendo en cuenta el punto anterior, hay que elegir si registrar el servicio en el **`Root Aplication Injector`** o en el **`Component Injector`**
* Como **`Component Injector`** se usaria en el caso de que un **`servicio`** traquee o haga algo especifico con cada instancia del componente donde es registrado.
* El **`Dependency Injection`** se hace en el constructor del componente que va a usar el servicio.
* Antes de Angular 6, los servicios se registraban en el **`NgModule`**, sin embargo, se cambiò para favorecer el **`Tree Shaking`** [acà](https://coryrylan.com/blog/tree-shakeable-providers-and-services-in-angular) hay mas info.
* Màs data acerca de Dependency Injection [acà](https://medium.com/@tomastrajan/total-guide-to-angular-6-dependency-injection-providedin-vs-providers-85b7a347b59f)
* **Ver en el componente product-list la forma en que se Inyecta un servicio.**

15. **`Què son los Observables?`**
* *Reactive extensions (RxJS) representa una sequencia de datos como una secuencia observable, los cuales son llamados simplemente **"Observables"***
* **Los Observables:** 
* Manejan data asincrona (como la que viene del back end).
* Tratan los eventos como una colecciòn
* Se pueden pensar como un array cuyos items vienen de forma asincrona 
* Permiten que un mètodo se suscriba a ellos y de esta manera, recibir notificaciones asincronas cada vez que la data llega y gracias a esto, el mètodo realizarà una operaciòn cada vez que la data es ingresada a este, el mètodo tambièn recibe una notificaciòn cuando no hay mas data o cuando ocurre un error. 
* *Sin el `suscribe()` (que se puede pensar como un método que indica quien escucha al Observable), la `fuente de datos Observables` no va a emitir ningùn resultado. Los datos van a ser procesador pero no se van a emitir.*
* **Operadores del observable:**
* Permiten manipular sets de eventos con operadores, estos operadores son metodos dentro de los Observables que componen nuevos Observables (es decir, nuevos datos).
* Cada operador transforma el Observable, pero estos no esperan a tener todos los Observables para procesarlos, si no que los va procesando en cuanto son emitidos.
* [Acà](https://rxmarbles.com/) se puede ver la forma en que opera cada Observable 
* **Se pueden componer operadores**
* Con el **`Pipe method`** de un observable se puede componer un mètodo usando varios mètodos de los Observables (importados desde rxjs). los mètodos usados en el **.pipe()** se suelen llamar **`"pipeable operators"`**.
* Es convenciòn agregar al final del nombre de la variable que contiene un Observable un "$" 
* [Aca](https://medium.com/@AnkurRatra/demystifying-rxjs-observable-467c52309ac) se puede encontrar mas data acerca de los Observables.

16. **`Usar HTTP con Observables`**
* Revisar el archivo products.service.ts
* Se recomienda usar el módulo Http encapsulado en un servicio.

17. **`Router`** 
* `Un Router es un servicio`
* Revisar los archivos **`app-routing.module.ts`** y **`app.component.ts`** la forma en que se utilizan. El orden en que se configuran es el nombrado.
* La directiva **`routerLinkActive ="alguna-clase"`** permite que se le agregue al elemento en el momento en que el link está activo, esta directiva generalmente se pone dentro algún elemento clickeable, por ejemplo un **`<a>`** 
* Con la directiva **`[routerLink]`** se indica el lugar al que se redirige al dar click.
* La forma en que funciona el router es:
1. El usuario da click en el link y se activan las directivas puestas en el, la que redirige es **"routerLink"** quien,
2. Se conecta con el path puesto en app.routing.module.ts, en este modulo,
3. Se crea una instancia de la clase pasa a la propiedad **`component`**, despues
4. La vista del componente es inyectada a la directiva **`<router-outlet>`**
5. La página es mostrada.
* El orden en que se ponen las propiedades en el router importa, y va de más especifico a menos específico.
* Para accesar a parámetros de la URL se usa el servicio **`ActivatedRouter`** del mòdulo **`'@angular/router'`** sin embargo, hay 2 formas de hacerlo las cuales se explican [acá](https://medium.com/@tiboprea/accessing-url-parameters-in-angular-snapshot-vs-subscription-efc4e70f9053).
* **TL:DR** 
  1. `snapshot` se usa si **solo** se quiere capturar al paràmetro y desde el componente **no** se actualizarà la URL.
  2. `Observable` se usa si desde el componente se va a actualizar la url que se està capturando  
* En el componente **ProductDetailPageComponent** se ejemplifica còmo capturarlo con **snapshot**. 

18. **`Routing Guard`**
* Sirven para disponibilizar o hacer que las rutas tengan x comportamiento.
* [Acá](https://codingpotions.com/angular-seguridad/) hay mas info sobre este tema.
* Los guards se declaran en la sección del routing donde se encuentra la ruta donde se va a trabajar.
* *El guard es un servicio*, y por esta razón lo puse en la carpeta de services 

## Formularios

1. **`paràmetro disable`**
    * En el array de configuraciòn del input, se le puede pasar la propuiedad **`disabled`**, la cual recibe un booleano y lo que hace es desactivar el input y ademàs, quitarlo del model data.
2. **`setValue y patchValue`**
    * setValue da un valur a todos los input del formulario
    * patchValue da un valor a algunos input del formulario

## Crear con el Angular CLI

Con `ng generate component` más la ruta se puede generar un nuevo componente, pero también se pueden generar otros tipos de estructuras como `directive|pipe|service|class|guard|interface|enum|module`, algunos ejemplos de uso:

* **Componentes** = ng g c *ruta/de/destino/y/nombre-de-lo-creado*
* **Directivas** = ng g d *ruta/de/destino/y/nombre-de-lo-creado*
* **Servicios** = ng g s *ruta/de/destino/y/nombre-de-lo-creado*
* **Guards** = ng g g *ruta/de/destino/y/nombre-de-lo-creado*

### A tener en cuenta

* Es comùn recorrer arrays de objetos para mostrar sus propiedades en el DOM, esto se haria con un **for of**, y se hacen arrays porque son estructuras de datos iterables.
* Si se necesitan las Keys de los objetos se usa el mètodo **Object.key(nombreDelArray)**.
* Se recomienda poner la lògica de filtrado y ordenado directamente en el componente que lo va a usar. Angular no provee ningùn pipe para realizar estas tareas.
* Carga ùtil (payload) es la parte esencial y que finalmente se usa en la data recibida, https://en.wikipedia.org/wiki/Payload_(computing)
* Cada clase tiene un constructor el cual es ejecutado cuando la instanciaciòn de la clase es realizada, cuando no se crea un constructor en la clase, un constructor implicito es usado (Investigar al respecto)
* Debido a que la funciòn constructor es ejecutada cuando el componente es creado, esta debe ser usada solamente para inicializar variables y nunca para còdigo que tenga "side effect" o largo tiempo de ejecuciòn.
* Acá se tiene más información acerca de los métodos y propiedades privadas en una clase.
* El módulo de Router directamente se puede configurar en **`app.modules`**, con el método `forRoot()` quien recibe un array como parámetro.
* Los componentes página no necesitan un selector ya que no se van a anidar en ningún otro componente, además, estos componentes son los que se usan en el router.
* [Acá](https://flaviocopes.com/how-to-convert-string-to-number-javascript/) se puede ver la diferencia entre los diferentes métodos para convertir un string a un number.

## Development server

Con `ng serve` o `npm run start` (este segundo porque asi está definido en el package.json que se corra *ng serve*), se crea un dev server con recarga automática para no tener que actualizar la página del navegador ante cada cambio hecho en el código. Despues de correr *ng serve* el proyecto es levantado en `http://localhost:4200/`, además, en la linea de comandos también dice en qué puerto está levantado.

## Build

Con `ng build` o `npm run build` se compila la app dentro de una carpeta llamada **dist** y con el flag `--prod`, se hace un build para producción.

## Links utiles

1. Para ver el curso de donde sale la mayoria de la data, y la estructura de este readme, [seguir este enlace](https://www.pluralsight.com/courses/angular-2-getting-started-update).
2. Blogs ùtiles
   * [coryrylan.com](https://coryrylan.com/)
3. Pàginas ùtiles
   * Diagramas interactivos de los Observables [Acà](https://rxmarbles.com/)
4. Guia de estilo para quienes contribuyen en [Typescript](https://github.com/Microsoft/TypeScript/wiki/Coding-guidelines).
5. Glosario de [Angular](https://angular.io/guide/glossary).
6. Guía de estilos con buenas prácticas y recomendaciones para escribir aplicaciones con [Angular](https://angular.io/guide/styleguide).
7. Angular CLI
   * Para tener más data acerca del Angular CLI se puede usar `ng help` o ir a esta página [esta página](https://github.com/angular/angular-cli/blob/master/README.md).
8. Web de Karma, la herramienta usada por angular para correr [Test Unitarios](https://karma-runner.github.io).
9. Web de Protactos, la herramienta usada por angular para correr [Test End-To-End](http://www.protractortest.org/)