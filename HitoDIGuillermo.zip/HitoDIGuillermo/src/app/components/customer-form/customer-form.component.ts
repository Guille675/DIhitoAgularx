import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

import { Customer } from './customer';

@Component({
  selector: 'app-customer-form',
  templateUrl: './customer-form.component.html',
})

export class CustomerFormComponent implements OnInit {

  customerForm: FormGroup;
  /* Customer es una clase y no una interface debido a que se quiere instanciar,
  con la interfaz solamente se puede tener type checking */
  customer = new Customer();

  constructor(private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.customerForm = this.formBuilder.group({
      // Modelo de formulario son los input que se usaràn en el HTML.
      firstName: '',
      lastName: '',
      email: '',
      sendCatalog: true,
    });
  }

  populateTestData(): void {
    // Se pasa un objeto
    this.customerForm.setValue({
      firstName: 'hola',
      lastName: 'què',
      email: 'hace',
      sendCatalog: false,
    });
  }

  save(): void {
    console.log('hola');
  }

}
