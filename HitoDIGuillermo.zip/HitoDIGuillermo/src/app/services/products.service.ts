import { Injectable } from '@angular/core';
import { IProduct } from '../interfaces/product';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map} from 'rxjs/operators';

import { environment } from 'src/environments/environment';

@Injectable({
  // Con este paràmetro se hace que el servicio estè registrado como "Root Aplication Injector"
  providedIn: 'root'
})

export class ProductsService {
  // Se esconde la ruta del src en una variable de ambiente para mantenerla segura.
  private productSrc = environment.src;

              /* Se inyecta el módulo http de Angular como un servicio
              y sirve para manejar comunicación en una arquitectura REST.*/
  constructor(private http: HttpClient) {}

  /* Al hacer un get al servidor, lo que se devuelve es un Observable
  con la estructura de IProduct, por esta razón se usa como generic.*/
  getProducts(): Observable<IProduct[]> {
                // Con el Generic se da un formato (transforma) la data traida por el Get.
    return this.http.get<IProduct[]>(this.productSrc).pipe(
      catchError(this.handleError)
    );
    /* Este pipe funciona solamente como demostración de uso de PipeResolver,
    en el método getProduct() aparece un caso más real.
    */
    // .pipe(
    //   tap(data => (
    //     /*Este método muestra la data del back-end sin ser procesada, por
    //     esto se usa para enviar los errores a el servicio donde quedan registrados
    //     los errores, además, se usa el método del JSON para convertirla en string:*/

    //     console.log(`${JSON.stringify(data)}`)
    //   )),
    //   catchError(this.handleError)
    // );
  }

  getProduct(id: number): Observable<IProduct | undefined> {
    return this.getProducts().pipe(
      /* No se puede usar filter, por que de entrada modifica el array y el mismo deja de
      ser del tipo IProduct, por esta razón lo que se hace es usar map para crear una
      copia y despues modificarlo con el find()*/
      map( (products: IProduct[]) => products.find(product => product.productId === id))
    );
  }

  private handleError(err: HttpErrorResponse) {
    // in a real world app, we may send the server to some remote logging infrastructure
    // instead of just logging it to the console
    let errorMessage = '';
    if (err.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      errorMessage = `An error occurred: ${err.error.message}`;
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      errorMessage = `Server returned code: ${err.status}, error message is: ${err.message}`;
    }

    console.error(errorMessage);
    return throwError(errorMessage);
  }
}
