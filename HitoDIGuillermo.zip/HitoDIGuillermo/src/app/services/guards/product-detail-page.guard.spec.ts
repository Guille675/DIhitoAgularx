import { TestBed, async, inject } from '@angular/core/testing';

import { ProductDetailPageGuard } from './product-detail-page.guard';

describe('ProductDetailPageGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ProductDetailPageGuard]
    });
  });

  it('should ...', inject([ProductDetailPageGuard], (guard: ProductDetailPageGuard) => {
    expect(guard).toBeTruthy();
  }));
});
