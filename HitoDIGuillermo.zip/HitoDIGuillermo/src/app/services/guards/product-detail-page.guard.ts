import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { flattenStyles } from '@angular/platform-browser/src/dom/dom_renderer';

// Este servicio va a estar disponible en toda la app.
@Injectable({
  providedIn: 'root'
})

export class ProductDetailPageGuard implements CanActivate {

  // Inyecto el servicio del Router ya que se va a usar en el método del guard.
  constructor(private router: Router) {

  }

  // Puede retornar un boolean, un Observable o una promesa, depende del caso.
  canActivate(
    // Este primer parámetro da información acerca de la url.
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean> | Promise<boolean> | boolean {

          /* En la propiedad url de route se guarda cada parte de la url y supongo que lo
          hace en un array porque para acceder a cada parte se cuenta desde el 0 (base 0),
          como quiero el id entonces pido el 2do parámetro ya que el primero es "productos".*/
    let id = Number(route.url[1].path);

    if (isNaN(id) || id < 1) {
      /* normalmente no se enrutaria a products ni se mostraria una alerta, si no que se
      llevaria al usuario a una pàgina de error.*/
      alert('ID de producto inválido');
      this.router.navigate(['/productos']);
      return false;
      // Se retorna false para cancelar la operaciòn de la ruta incorrecta
    }

    // Se retorna true para que el router continue el enrutambiento que estaba haciendo.
    return true;
  }
}
