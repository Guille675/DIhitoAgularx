import { FilterProductsPipe } from './filter-products.pipe';

describe('FilterProductsPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterProductsPipe();
    expect(pipe).toBeTruthy();
  });
});
