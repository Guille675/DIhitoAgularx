import { Pipe, PipeTransform } from '@angular/core';

// Decorador del Pipe que indica el nombre con el que se utilizarà dentro del HTML.
@Pipe({ 
  name: 'convertToSpaces'
})

export class ConvertToSpacesPipe implements PipeTransform {

  // PipeTransform pide al menos un mètodo transform().

  /* El primer paràmetro recibe el valor a convertir por el Pipe, y
          el segundo, es el paràmetro que recibe el Pipe. */
  transform(value: string, character: string): string {
    /* replace() es un mètodo de JS, y como segundo paràmetro recibe un regex con los valores a
    remplazar, o directamente el valor a remplazar (como es en este caso). */
    return value.replace(character, ' ');
  }

}
