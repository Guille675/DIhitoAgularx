import { Component, OnChanges, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-star-rating',
  templateUrl: './star-rating.component.html',
  styles: [
    'div: {cursor: pointer}',
    '.crop {overflow: hidden}',
    '.stars-container{width: 75px;}',
  ]
})
export class StarRatingComponent implements OnChanges {

  /* La data entra desde el parent component porque allì es donde se usa el componente.
    El decorador @Input es un mètodo, por esto tiene parentesis.*/
  @Input() rating: number;

  /* En el HTML se usarà el property binding para pasar la data del html a la clase,
  pero gracias al input, la data ingresarà a este componente y no al componente donde
  es renderizado (product-list) . */

  // El @Output solamente puede ir con un EventEmitter.
  @Output() ratingMessage = new EventEmitter<string>();
          /* En el nombre, quitè el onClickSend porque en el on me tiraba error tslint,
          y se sobre entiende que se està enviando el mensaje, y el click, lo quite porque
          en este mètodo no hay click, el click està en el mètodo del Event Listener */

  starsContainerWidth: number;

  onClickRatingEmit(): void {
    this.ratingMessage.emit(`Se emite un mensaje que incluye el rating del producto ${this.rating}`);
  }

  // Escucha los cambios de un input property @Input.
  ngOnChanges(): void {
                      /* Con este calculo y el width de stars-container, se muestra la cantidad de
                      estrellas deseada, en si lo que hace es hacer que las estrellas permanezcan en
                      una linea y la caja contenedora se va agrandando a lo ancho para mostrar mas o
                      menos estrellas.*/
    this.starsContainerWidth = this.rating * 75 / 5;
  }
}
