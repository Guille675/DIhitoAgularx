import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomePageComponent } from './pages/home-page/home-page.component';
import { ProductListPageComponent } from './pages/product-list-page/product-list-page.component';
import { ProductDetailPageComponent } from './pages/product-detail-page/product-detail-page.component';

import { ProductDetailPageGuard } from './services/guards/product-detail-page.guard';

const routes: Routes = [
  // El orden del ruteo importa, y va de más específico a menos específico.
  { path: 'bienvenido', component: HomePageComponent },
  { path: 'productos', component: ProductListPageComponent },
  { path: 'productos/:id',
    canActivate: [ProductDetailPageGuard],
    component: ProductDetailPageComponent },
  { path: '', redirectTo: 'bienvenido', pathMatch: 'full' },
  // Este path se activa cuando la URL no coincide con ninguna de las configuradas.
  { path: '**', redirectTo: 'error404', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }
