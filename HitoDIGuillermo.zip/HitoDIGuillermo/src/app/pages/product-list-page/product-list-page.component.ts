import { Component, OnInit } from '@angular/core';

import { IProduct } from '../../interfaces/product';
import { ProductsService } from 'src/app/services/products.service';

// Decorador.
@Component({
  // Directiva
  selector: 'app-product-list',
  // Metadata del decorador para indicar la ubicación del html y css.
  templateUrl: './product-list-page.component.html',
  styleUrls: ['./product-list-page.component.scss'],

  // providers: [ProductsService] Esto se haria si se quiere inyectar el servicio desde el "Component Injector".
})
export class ProductListPageComponent implements OnInit {
  /* La interpolation tiene un flujo de datos "One way binding", que
  va de la clase al elemento html, dentro de este ùltimo, se define con
  "{{}}" y puede contener una propiedad, un calculo, o un mètodo*/
  pageTitle: string;
  showImage: boolean;
  errorMessage: string;
  products: IProduct[];
  filteredProducts: IProduct[];

  /* Se inicia con un guión bajo porque es una variable privada, y por esta razón, hay que configurar
  un getter y un setter.

  La convención del nombre de las propiedades privadas, hay que validarla con el grupo de trabajo.*/
  private _listFilter = '';
  // Cuando se necesita el valor, es llamada la variable por medio del getter
  get listFilter(): string {
    return this._listFilter;
  }

  /* cuando se le necesita dar un valor a la variable, entonces se llama al setter,
  ademàs, desde acà se decide si realizar el filtrado o devolver toodo el array de productos.*/
  set listFilter(value: string) {
    this._listFilter = value;
    this.filteredProducts = this.listFilter ? this.performFilter(this.listFilter) : this.products;
  }


  // El constructor() es un mètodo de la clase que se invoca cuando la clase del componente ha sido instanciada/
  constructor(private productService: ProductsService) {
        /* El "Service Injection" se hace en el constructor y se usa
          como private para que se pueda usar en todo el componente.*/
    this.showImage = false;
    this.products = [];
    this.filteredProducts = [];

    // Al no indicar un valor para el listFilter, de forma predeterminada mostrarà todos los items.
    // this.listFilter = '';
  }

  receiveRatingMessage(message: string): void {
    this.pageTitle = `Product List: ${message}`;
  }

  /* Se recomienda poner la lògica del filtrado u ordenado de items dentro del componente
  para tener mejor rendimiento. */
  performFilter(filterBy: string): IProduct[] {
    filterBy = filterBy.toLocaleLowerCase();

    return this.products.filter((product: IProduct) => {
      return product.productName.toLocaleLowerCase().indexOf(filterBy) !== -1;
    });
  }

  toggleImage(): void {
    this.showImage = !this.showImage;
  }

  ngOnInit() {
    /* Como el servicio generalmente se consume desde un servidor,
    dejar la llamada en el constructor va a hacer que cargue lento el componente,
    por esta razòn se deja en el lifecycle hook method ngOnInit(), ya que en este caso,
    el servicio se empieza a consumir cuando el componente ha acabado de cargar.*/
    this.productService.getProducts().subscribe(
      product => {
        this.filteredProducts = product;
        /* El "llenado" del array de los productos filtrados se pone dentro de la suscripción
        ya que los Observables vienen de forma asincrona y en el primer método de la suscripción.

        Si filtederProducts se pusiera fuera de la suscripción, el array se mantendria vacio aunque
        este se referenciara acá, dentro de la suscripción, debido a que aunque en el orden del
        código va primero la suscripción y despues la llamada a filteredProducts, .suscribe() es asincrono.
        
        La forma en que se traen los datos desde el servicio es:
        1 Se llama al método getProducts del servicio, -el cual es un Observable-,
        2 Se hace la suscripción para estar atento a que llegue la data,
        3 El servidor contesta la data y desde la suscripción se llena el arra "filteredProducts"
        */
      },
                      // Se usa Type assertion o Casting en otros lenguajes
      error => this.errorMessage = error as any
                      /* no uso esta notación (<any>) para hacer el Type assertion
                      porque el tslint me dice que mejor use un alias*/
    );
  }
}
