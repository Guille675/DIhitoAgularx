import { Component, OnInit } from '@angular/core';

@Component({
  templateUrl: './home-page.component.html',
  // styleUrls: ['./home-page.component.scss']
})
export class HomePageComponent implements OnInit {

  public pageTitle = 'Welcome';

  // constructor() { }

  ngOnInit() {
  }

}
