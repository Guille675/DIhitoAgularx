import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { IProduct } from 'src/app/interfaces/product';
import { ProductsService } from 'src/app/services/products.service';

@Component({
  // // Se quita el selector porque es una página y no se usará como componente.
  // selector: 'app-product-detail-page',
  templateUrl: './product-detail-page.component.html',
  styles: ['tr > td {padding: 0.6rem;}',
           '.load-container {height: 60vh;}'],
})

export class ProductDetailPageComponent implements OnInit {

  pageTitle: string;
  productId: number;
  product: IProduct;
  load: boolean;
  errorMessage: string;

  constructor(private route: ActivatedRoute,
              private router: Router,
              private productService: ProductsService
    ) {
    this.pageTitle = 'Detalle del producto';
    this.load = true;
  }

  // Hace falta maquetar el listado y buscar el producto por id, en el curso de React vi una forma elegante de hacerlo.

  ngOnInit() {
    /* Desde acá se captura el id puesto en la url, y gracias a esto
    se puede traer el artículo correcto. Como usaré este valor cuando la clase está instanciada,
    entonces lo pongo en este lifecycle hook.*/
    this.productId = Number(this.route.snapshot.paramMap.get('id'));
    this.getProduct(this.productId);
  }

  // Se consume el servicio para traer los productos desde el get hecho en el servicio.
  getProduct(id: number) {
    this.productService.getProduct(id).subscribe(
      filteredProduct => {
        this.product = filteredProduct;
        this.load = false;
      },
      error => this.errorMessage = error as any
    );
  }

  onBack(): void {
    /* La lógica del routing se puede poner directamente en el HTML (como se hizo en el app.component.ts),
    pero en caso de que se vayan a hacer mas cosas con el click, se pone en el archivo ts de la página.*/
    this.router.navigate(['/productos']);
  }
}
