import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

import { ConvertToSpacesPipe } from './shared/convert-to-spaces.pipe';
import { FilterProductsPipe } from './shared/filter-products.pipe';


import { AppComponent } from './app.component';
import { HomePageComponent } from './pages/home-page/home-page.component';
import { ProductListPageComponent } from './pages/product-list-page/product-list-page.component';
import { ProductDetailPageComponent } from './pages/product-detail-page/product-detail-page.component';
import { StarRatingComponent } from './shared/components/star-rating/star-rating.component';
import { CustomerFormComponent } from './components/customer-form/customer-form.component';

@NgModule({
  // Acá van los Componentes, las directivas y los Pipe
  declarations: [
    AppComponent,
    HomePageComponent,
    ProductListPageComponent,
    ProductDetailPageComponent,
    StarRatingComponent,
    CustomerFormComponent,
    FilterProductsPipe,
    ConvertToSpacesPipe,
  ],
  // Desde acà se importan los modulos a usar
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    MatProgressSpinnerModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
