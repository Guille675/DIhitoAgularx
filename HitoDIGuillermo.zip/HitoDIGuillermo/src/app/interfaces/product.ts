/* La I como prefijo del nombre es opcional, por ejemplo,
en la guia de estilo para los contribuidores de TS piden
evitar ese prefijo. https://github.com/Microsoft/TypeScript/wiki/Coding-guidelines*/
export interface IProduct {
  productId: number;
  productName: string;
  productCode: string;
  releaseDate: string;
  price: number;
  description: string;
  starRating: number;
  imageUrl: string;
}
