import { Component } from '@angular/core';

@Component({
  /* Un Decorador es una funciòn que provee de metada al componente.
  La propiedad "selector", setea una Directiva, (una directiva es un
  elemento HTML custom donde ira el componente el template que se està
  definiendo) a usarse para invocar el componente.

  esta propiedad no es necesaria si el componente no se renderizarà en ningun lugar.*/
  selector: 'app-root',
  template: `
    <nav class='navbar navbar-expand navbar-light bg-light'>
      <a class='navbar-brand'>{{pageTitle}}</a>
      <ul class='nav nav-pills'>
        <li><a class='nav-link' routerLinkActive='active' [routerLink]="['/bienvenido']">Home</a></li>
        <li><a class='nav-link' routerLinkActive='active' [routerLink]="['/productos']">Nuestros productos</a></li>
      </ul>
    </nav>
    <div class='container'>
      <router-outlet></router-outlet>
    </div>
  `,
})

export class AppComponent {
  pageTitle = 'Aluve';
}
